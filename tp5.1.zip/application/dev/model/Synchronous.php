<?php


namespace app\dev\model;

use think\Model;

class Synchronous extends Model
{
    protected $pk = 'id'; //指定主键

    // 模型初始化
    protected static function init()
    {
        //TODO:初始化内容
    }
}